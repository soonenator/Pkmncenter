import * as THREE from './vendor/three.module.js';
import { OrbitControls } from './vendor/addons/controls/OrbitControls.js';
import { FontLoader } from './vendor/addons/loaders/FontLoader.js';
import { createCenter } from './scene.js';
import { createGameState } from './state.js';

const $=id=>document.getElementById(id);
const viewport=$('viewport'), dialog=$('dialog'), content=$('dialog-content');
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)').matches;
const state=createGameState();
const fontResponse=await fetch('./assets/helvetiker_bold.typeface.json');
if(!fontResponse.ok)throw new Error('Font asset is missing');
const font=new FontLoader().parse(await fontResponse.json());
const center=createCenter(font);
const scene=new THREE.Scene();scene.background=new THREE.Color(0xedf0ea);
scene.add(center.world);
const renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
renderer.setPixelRatio(Math.min(window.devicePixelRatio,innerWidth<800?1.5:2));
renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;
renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.18;
viewport.appendChild(renderer.domElement);
const camera=new THREE.PerspectiveCamera(37,1,.1,200);
const controls=new OrbitControls(camera,renderer.domElement);
controls.enableDamping=!reducedMotion;controls.dampingFactor=.075;controls.minDistance=6;controls.maxDistance=110;controls.minPolarAngle=.18;controls.maxPolarAngle=Math.PI/2-.04;controls.maxTargetRadius=16;
controls.target.set(0,1,0);camera.position.set(23,20,27);controls.update();
const ambient=new THREE.HemisphereLight(0xf2ffe5,0x829394,2.3);scene.add(ambient);
const sun=new THREE.DirectionalLight(0xffefdb,3.7);sun.position.set(-12,22,12);sun.castShadow=true;
sun.shadow.mapSize.setScalar(innerWidth<800?1024:2048);sun.shadow.camera.left=-20;sun.shadow.camera.right=20;sun.shadow.camera.top=20;sun.shadow.camera.bottom=-20;sun.shadow.camera.near=.1;sun.shadow.camera.far=60;sun.shadow.normalBias=.06;scene.add(sun);
const fill=new THREE.DirectionalLight(0xc4e3ff,1.25);fill.position.set(14,8,-5);scene.add(fill);
const nightLights=center.lightPositions.map(p=>{const l=new THREE.PointLight(0xffd69a,0,12,2);l.position.set(...p);scene.add(l);return l;});
const healingLight=new THREE.PointLight(0xff648b,0,8,2);healingLight.position.set(1.8,3,-2.6);scene.add(healingLight);
// Matte ground receives shadows beneath the floating model.
const backdrop=new THREE.Mesh(new THREE.PlaneGeometry(200,200),new THREE.ShadowMaterial({opacity:.095}));backdrop.rotation.x=-Math.PI/2;backdrop.position.y=-1.18;backdrop.receiveShadow=true;scene.add(backdrop);
let mode='orbit',night=false,sound=false,audioContext,transition=null,nearest=null,lastTime=performance.now(),elapsed=0,toastTimer,selectedSwap=null;
let healingStart=null,healingFinishTimer,healingSnapshot=[],lastUiTime=0;
const keys=new Set();const waveUntil=new Map();
const walkOffset=new THREE.Vector3(8,10,12);
const raycaster=new THREE.Raycaster();const pointer=new THREE.Vector2();const projection=new THREE.Vector3();
const forward=new THREE.Vector3(),right=new THREE.Vector3(),up=new THREE.Vector3(0,1,0),movement=new THREE.Vector3();
const focusPoint=new THREE.Vector3(),desiredCamera=new THREE.Vector3();
const markerElements=new Map();
for(const h of center.hotspots){const button=document.createElement('button');button.className='marker';button.textContent='+';button.setAttribute('aria-label',h.label);button.addEventListener('click',()=>activate(h.id));$('markers').appendChild(button);markerElements.set(h.id,button);}

function notify(message){clearTimeout(toastTimer);$('toast').textContent=message;$('toast').hidden=false;toastTimer=setTimeout(()=>$('toast').hidden=true,3400);}
function playNotes(notes,spacing=.15){
  if(!sound)return;
  try{audioContext??=new (window.AudioContext||window.webkitAudioContext)();if(audioContext.state==='suspended')void audioContext.resume();notes.forEach((freq,i)=>{const o=audioContext.createOscillator(),g=audioContext.createGain();o.type='sine';o.frequency.value=freq;const t=audioContext.currentTime+i*spacing;g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.055,t+.015);g.gain.exponentialRampToValueAtTime(.001,t+.23);o.connect(g).connect(audioContext.destination);o.start(t);o.stop(t+.25);});}catch{sound=false;setSoundLabel();}
}
function avatar(p){return `<span class="pokemon-avatar" style="--tint:${p.tint};--color:${p.color}" aria-hidden="true">${p.initial}</span>`;}
function renderParty(progress=null){
  $('party').innerHTML=state.getParty().map((p,i)=>{const hp=progress===null?p.hp:Math.round(healingSnapshot[i]+(p.max-healingSnapshot[i])*progress);const percent=Math.round(hp/p.max*100);return `<div class="party-card">${avatar(p)}<div class="pokemon-info"><div class="pokemon-name">${p.name}<small>Lv. ${p.level}</small></div><div class="health" role="meter" aria-label="${p.name} HP" aria-valuemin="0" aria-valuemax="${p.max}" aria-valuenow="${hp}"><span style="width:${percent}%;background:${percent<45?'#dda45e':'#81ad70'}"></span></div><div class="hp-text"><span>${p.type}</span><span>${hp} / ${p.max} HP</span></div></div></div>`;}).join('');
  $('party-note').textContent=state.healing?'A little care goes a long way.':state.getParty().every(p=>p.hp===p.max)?'Feeling great. Ready for the next adventure.':'A quick rest will do them good.';
}
function moveCamera(position,target,duration=.7){transition={start:performance.now(),duration:reducedMotion?1:duration*1000,from:camera.position.clone(),to:position.clone(),targetFrom:controls.target.clone(),targetTo:target.clone()};}
function overview(){
  const target=new THREE.Vector3(0,1,0),offset=new THREE.Vector3(23,19,27),testCamera=camera.clone();
  // Fit the complete model in both axes, including tall phone screens.
  for(let pass=0;pass<8;pass++){
    testCamera.position.copy(target).add(offset);testCamera.lookAt(target);testCamera.updateMatrixWorld();let fit=1;
    for(const x of [-11,11])for(const y of [-1.16,6.78])for(const z of [-9,9]){const p=new THREE.Vector3(x,y,z).project(testCamera);fit=Math.max(fit,Math.abs(p.x)/.89,Math.abs(p.y)/.89);}
    if(fit<=1.001)break;offset.multiplyScalar(fit);
  }
  moveCamera(target.clone().add(offset),target);
}
function setRoof(show){if(show&&mode==='walk')setMode('orbit');center.shell.visible=show;$('roof').setAttribute('aria-pressed',String(show));$('roof-label').textContent=show?'Cutaway':'Show roof';$('view-label').textContent=show?'EXTERIOR VIEW':mode==='walk'?'EXPLORING':'INTERIOR VIEW';}
function setMode(next){
  mode=next;keys.clear();controls.enabled=next==='orbit';transition=null;
  $('orbit').classList.toggle('selected',next==='orbit');$('walk').classList.toggle('selected',next==='walk');$('orbit').setAttribute('aria-pressed',String(next==='orbit'));$('walk').setAttribute('aria-pressed',String(next==='walk'));
  $('walk-pad').hidden=next!=='walk';$('interact').hidden=true;
  $('controls-hint').innerHTML=next==='walk'?'<span class="keycap">W A S D</span> or arrows to walk <span class="keycap">E</span> interact':'<span class="keycap">drag</span> rotate <span class="keycap">scroll</span> zoom <span class="hint-extra">· tap a marker to interact</span>';
  if(next==='walk'){setRoof(false);notify('Walk through the doorway. Press E near a friend or station.');viewport.focus({preventScroll:true});}else overview();
  $('view-label').textContent=center.shell.visible?'EXTERIOR VIEW':next==='walk'?'EXPLORING':'INTERIOR VIEW';
}
function openDialog(html){keys.clear();content.innerHTML=html;if(!dialog.open)dialog.showModal();}
function closeDialog(){dialog.close();if(mode==='walk')viewport.focus({preventScroll:true});}
function welcome(){
  openDialog(`<div class="dialog-symbol" aria-hidden="true">✚</div><p class="dialog-eyebrow">NURSE JOY</p><h2 class="dialog-title" id="dialog-title">Welcome to our Pokémon Center!</h2><p class="dialog-copy">Your Pokémon have been working hard. Shall we take them for a few moments and restore their health?</p><div class="dialog-actions"><button class="primary" id="heal-party">Yes, please!</button><button class="secondary" id="maybe-later">Just saying hello</button></div>`);
  $('heal-party').addEventListener('click',healParty);$('maybe-later').addEventListener('click',()=>{closeDialog();notify('Nurse Joy: You’re always welcome here!');});
  waveUntil.set('joy',elapsed+2);playNotes([523,659]);
}
function healParty(){
  if(!state.beginHealing())return;
  healingStart=performance.now();healingSnapshot=state.getParty().map(p=>p.hp);
  center.healBalls.forEach((ball,i)=>{ball.visible=i<state.party.length;});
  openDialog(`<div class="dialog-symbol" aria-hidden="true">♡</div><p class="dialog-eyebrow">TAKING GOOD CARE</p><h2 class="dialog-title" id="dialog-title">A moment to recharge.</h2><p class="dialog-copy" id="heal-status" role="status">Your Pokémon are resting at the healing station.</p><div class="heal-track" aria-hidden="true"><span id="heal-progress"></span></div><p class="pc-help">You can close this window and watch the healing station.</p>`);
  renderParty();playNotes([392,494,587,659,784],.22);
  clearTimeout(healingFinishTimer);healingFinishTimer=setTimeout(finishHealing,4200);
}
function finishHealing(){
  if(!state.finishHealing())return;
  healingStart=null;healingLight.intensity=0;center.healBalls.forEach(b=>{b.visible=false;b.position.y=.51;});renderParty();
  playNotes([523,659,784,1047],.13);
  if(dialog.open){openDialog(`<div class="dialog-symbol" aria-hidden="true">✧</div><p class="dialog-eyebrow">ALL BETTER</p><h2 class="dialog-title" id="dialog-title">Healthy, happy, and ready.</h2><p class="dialog-copy">Your Pokémon have been restored to full health. We hope to see you again!</p><div class="dialog-actions"><button class="primary" id="heal-done">Thanks, Nurse Joy!</button></div>`);$('heal-done').addEventListener('click',closeDialog);}else notify('Your party is fully healed. Ready for the next adventure!');
}
function renderPC(){
  const stored=state.getStored()[0];
  openDialog(`<div class="dialog-symbol pc-icon" aria-hidden="true">▦</div><p class="dialog-eyebrow">SOMEONE’S PC · BOX 01</p><h2 class="dialog-title" id="dialog-title">A friend for the road.</h2><p class="pc-help">Choose a Pokémon in your party, then exchange it with ${stored.name}. Your party’s health stays with each Pokémon.</p><div class="pc-slots">${state.getParty().map(p=>`<button class="pc-slot ${selectedSwap===p.id?'chosen':''}" data-swap="${p.id}" aria-pressed="${selectedSwap===p.id}">${avatar(p)}<span><strong>${p.name}</strong><small>Lv. ${p.level} · ${p.hp}/${p.max} HP</small></span><span>${selectedSwap===p.id?'Selected':'In party'}</span></button>`).join('')}</div><p class="dialog-eyebrow">IN STORAGE</p><button class="pc-slot" id="exchange" ${selectedSwap?'':'disabled'}>${avatar(stored)}<span><strong>${stored.name}</strong><small>Lv. ${stored.level} · ${stored.hp}/${stored.max} HP</small></span><span>Exchange ↔</span></button>`);
  content.querySelectorAll('[data-swap]').forEach(button=>button.addEventListener('click',()=>{selectedSwap=button.dataset.swap;renderPC();content.querySelector(`[data-swap="${selectedSwap}"]`).focus();}));
  $('exchange').addEventListener('click',()=>{const outgoing=state.pokemon.find(p=>p.id===selectedSwap);if(!state.swap(selectedSwap,stored.id))return;selectedSwap=null;renderParty();renderPC();notify(`${stored.name} joined your party. ${outgoing.name} is in Box 01.`);playNotes([659,784]);});
}
const creatureCopy={
  pikachu:['Pika, pika!','Pikachu’s cheeks give a tiny, cheerful spark. It looks very pleased to see you.','Give a gentle pet','Pikachu leans into your hand. Pika!'],
  bulbasaur:['Bulba-saur!','Bulbasaur found a cozy patch of sunlight by the waiting area. Its bulb sways as you approach.','Say hello','Bulbasaur gives a happy little bounce.'],
  charmander:['Char, char!','Charmander is watching the healing machine. Its tail flame glows warmly in the lobby.','Give a little wave','Charmander waves back. Its tail flickers with excitement!'],
  squirtle:['Squirtle, squirt!','Squirtle is enjoying the fresh air outside. It tilts its head and gives you a friendly grin.','Say hello','Squirtle bounces happily. You made a new friend!']
};
function activate(id){
  const h=center.hotspots.find(h=>h.id===id);if(!h)return;
  if(mode==='walk'&&Math.hypot(center.trainer.position.x-h.reach.x,center.trainer.position.z-h.reach.z)>2.15){notify('Walk a little closer to interact.');return;}
  if(state.healing){notify('Your Pokémon are still being healed. Just a moment!');return;}
  $('toast').hidden=true;document.querySelector('.sidebar').classList.remove('open');$('mobile-party').setAttribute('aria-expanded','false');
  if(mode==='orbit'){setRoof(false);const p=h.reach.clone();p.y=1;moveCamera(p.clone().add(new THREE.Vector3(6,6.4,8)),p);}
  if(id==='joy'||id==='heal')return welcome();
  if(id==='pc'){selectedSwap=null;renderPC();playNotes([784,659]);return;}
  const p=state.pokemon.find(p=>p.id===id),copy=creatureCopy[id];
  openDialog(`<div class="dialog-symbol" style="background:${p.tint};color:${p.color}" aria-hidden="true">${p.initial}</div><p class="dialog-eyebrow">#${p.number} · ${p.name.toUpperCase()}</p><h2 class="dialog-title" id="dialog-title">${copy[0]}</h2><p class="dialog-copy">${copy[1]}</p><div class="dialog-actions"><button class="primary" id="greet-pokemon">${copy[2]}</button><button class="secondary" id="bye-pokemon">See you around</button></div>`);
  $('greet-pokemon').addEventListener('click',()=>{waveUntil.set(id,elapsed+2.5);closeDialog();notify(copy[3]);playNotes([659,784,988],.1);});$('bye-pokemon').addEventListener('click',closeDialog);
}
function setSoundLabel(){$('sound').setAttribute('aria-pressed',String(sound));$('sound').querySelector('.button-label').textContent=sound?'Sound on':'Sound off';$('sound').setAttribute('aria-label',sound?'Turn sound off':'Turn sound on');}
$('sound').addEventListener('click',()=>{sound=!sound;setSoundLabel();if(sound)playNotes([523,659,784]);});
$('day').addEventListener('click',()=>{night=!night;document.body.classList.toggle('night',night);scene.background.set(night?0x172c29:0xedf0ea);ambient.intensity=night?.65:2.3;sun.intensity=night?.7:3.7;sun.color.set(night?0x9dbdf5:0xffefdb);fill.intensity=night?.9:1.25;nightLights.forEach(l=>l.intensity=night?24:0);renderer.toneMappingExposure=night?1.25:1.18;$('day').setAttribute('aria-pressed',String(night));$('day').setAttribute('aria-label',night?'Switch to daylight':'Switch to evening');$('day').querySelector('.button-label').textContent=night?'Evening':'Daylight';$('day').querySelector('span').textContent=night?'☾':'☀';$('mood-label').textContent=night?'The light is always on for you.':'A little place to recharge.';});
$('orbit').addEventListener('click',()=>setMode('orbit'));
$('walk').addEventListener('click',()=>setMode('walk'));
$('roof').addEventListener('click',()=>{setRoof(!center.shell.visible);overview();});
$('reset').addEventListener('click',()=>{center.trainer.position.set(.1,.23,5.8);center.trainer.rotation.y=0;setMode('orbit');setRoof(false);overview();});
$('close-dialog').addEventListener('click',closeDialog);
dialog.addEventListener('click',e=>{if(e.target===dialog){const r=dialog.getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)closeDialog();}});
dialog.addEventListener('close',()=>keys.clear());
$('mobile-party').addEventListener('click',()=>{const open=document.querySelector('.sidebar').classList.toggle('open');$('mobile-party').setAttribute('aria-expanded',String(open));});
document.querySelectorAll('[data-action]').forEach(button=>button.addEventListener('click',()=>activate(button.dataset.action)));
$('interact').addEventListener('click',()=>{if(nearest)activate(nearest.id);});
$('help').addEventListener('click',()=>openDialog(`<div class="dialog-symbol" aria-hidden="true">?</div><p class="dialog-eyebrow">MAKE YOURSELF AT HOME</p><h2 class="dialog-title" id="dialog-title">A little help exploring.</h2><ul class="help-list"><li><strong>Rotate the model</strong><span>Drag with one finger or mouse</span></li><li><strong>Zoom in / out</strong><span>Pinch or scroll</span></li><li><strong>Pan the view</strong><span>Two fingers or right-drag</span></li><li><strong>Walk around</strong><span>Explore → WASD / arrows / pad</span></li><li><strong>Interact</strong><span>Tap a + marker, or press E nearby</span></li><li><strong>See the exterior</strong><span>Show roof</span></li><li><strong>Start over</strong><span>Reset view</span></li></ul><p class="pc-help">Use Tab to reach every station and control. Sound starts only when you turn it on. Your party resets when you reload. The GLB download contains the full building and characters as an editable static model.</p>`));

// Raycasting makes the actual 3D characters clickable as well as their markers.
let pointerDown=null;
renderer.domElement.addEventListener('pointerdown',e=>{pointerDown={x:e.clientX,y:e.clientY,time:performance.now()};});
renderer.domElement.addEventListener('pointerup',e=>{
  if(!pointerDown||Math.hypot(e.clientX-pointerDown.x,e.clientY-pointerDown.y)>6||performance.now()-pointerDown.time>650){pointerDown=null;return;}
  pointerDown=null;const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(pointer,camera);
  const hits=raycaster.intersectObject(center.world,true).filter(hit=>{let obj=hit.object;while(obj){if(!obj.visible)return false;obj=obj.parent;}return true;});
  const first=hits[0];if(first?.object.userData.interaction)activate(first.object.userData.interaction);
});
renderer.domElement.addEventListener('pointercancel',()=>pointerDown=null);
const movementKeys=['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowLeft','ArrowDown','ArrowRight'];
window.addEventListener('keydown',e=>{if(dialog.open)return;if(mode==='walk'&&movementKeys.includes(e.code)){e.preventDefault();keys.add(e.code);}if(mode==='walk'&&e.code==='KeyE'&&!e.repeat&&nearest){e.preventDefault();activate(nearest.id);}if(e.code==='Escape'&&mode==='walk')setMode('orbit');});
window.addEventListener('keyup',e=>keys.delete(e.code));window.addEventListener('blur',()=>keys.clear());
document.addEventListener('visibilitychange',()=>{keys.clear();lastTime=performance.now();});
document.querySelectorAll('[data-key]').forEach(button=>{const clear=()=>keys.delete(button.dataset.key);button.addEventListener('pointerdown',e=>{e.preventDefault();button.setPointerCapture(e.pointerId);keys.add(button.dataset.key);});button.addEventListener('pointerup',clear);button.addEventListener('pointercancel',clear);button.addEventListener('lostpointercapture',clear);});

// Export the full, independent 3D model. Generated file never contains a server dependency.
$('download').addEventListener('click',async()=>{
  const button=$('download');button.disabled=true;
  try{const {GLTFExporter}=await import('./vendor/addons/exporters/GLTFExporter.js');const exportWorld=center.world.clone(true);exportWorld.traverse(o=>{if(o.name==='Removable roof and facade')o.visible=true;});
    const data=await new GLTFExporter().parseAsync(exportWorld,{binary:true,onlyVisible:true});const url=URL.createObjectURL(new Blob([data],{type:'model/gltf-binary'}));const a=document.createElement('a');a.href=url;a.download='pokemon-center.glb';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);notify('Your 3D model is ready. Open it in Blender or a glTF viewer.');
  }catch(error){console.error(error);notify('The model download failed. Please try again.');}finally{button.disabled=false;}
});

let previousAspect=null;
function resize(){const w=viewport.clientWidth,h=viewport.clientHeight;if(!w||!h)return;renderer.setSize(w,h);camera.aspect=w/h;camera.updateProjectionMatrix();if(previousAspect!==null&&Math.abs(previousAspect-camera.aspect)>.15&&mode==='orbit')overview();previousAspect=camera.aspect;}
new ResizeObserver(resize).observe(viewport);resize();overview();renderParty();setSoundLabel();$('day').setAttribute('aria-label','Switch to evening');
function updateWalking(dt){
  const movingForward=Number(keys.has('KeyW')||keys.has('ArrowUp'))-Number(keys.has('KeyS')||keys.has('ArrowDown'));
  const movingSide=Number(keys.has('KeyD')||keys.has('ArrowRight'))-Number(keys.has('KeyA')||keys.has('ArrowLeft'));
  movement.set(0,0,0);
  if(!dialog.open&&(movingForward||movingSide)){
    camera.getWorldDirection(forward);forward.y=0;forward.normalize();right.crossVectors(forward,up).normalize();movement.addScaledVector(forward,movingForward).addScaledVector(right,movingSide).normalize().multiplyScalar(dt*3.3);
    const p=center.trainer.position;if(center.canStand(p.x+movement.x,p.z))p.x+=movement.x;if(center.canStand(p.x,p.z+movement.z))p.z+=movement.z;
    center.trainer.rotation.y=Math.atan2(movement.x,movement.z);
  }
  const stride=movement.length()>0&&!reducedMotion?Math.sin(elapsed*12)*.36:0;
  center.limbs.legs[0].rotation.x=stride;center.limbs.legs[1].rotation.x=-stride;center.limbs.arms[0].rotation.x=-stride;center.limbs.arms[1].rotation.x=stride;
  focusPoint.copy(center.trainer.position);focusPoint.y=1;desiredCamera.copy(focusPoint).add(walkOffset);camera.position.lerp(desiredCamera,reducedMotion?1:1-Math.exp(-dt*5));controls.target.copy(focusPoint);camera.lookAt(focusPoint);
  nearest=null;let best=2.15;for(const h of center.hotspots){const d=Math.hypot(center.trainer.position.x-h.reach.x,center.trainer.position.z-h.reach.z);if(d<best){best=d;nearest=h;}}
  $('interact').hidden=!nearest||dialog.open||state.healing||!$('toast').hidden;if(nearest)$('interact-label').textContent=nearest.label;
}
function frame(now){
  const dt=Math.min((now-lastTime)/1000,.035);lastTime=now;elapsed+=dt;
  if(mode==='walk')updateWalking(dt);
  else if(transition){const t=Math.min(1,(now-transition.start)/transition.duration),s=t*t*(3-2*t);camera.position.lerpVectors(transition.from,transition.to,s);controls.target.lerpVectors(transition.targetFrom,transition.targetTo,s);if(t>=1)transition=null;controls.update();}
  else controls.update();
  if(!reducedMotion){
    center.creatures.forEach((creature,i)=>{const active=(waveUntil.get(creature.name.toLowerCase())??0)>elapsed;creature.position.y=.23+(active?Math.abs(Math.sin(elapsed*9))*.23:Math.sin(elapsed*2+i)*.018);if(active)creature.rotation.z=Math.sin(elapsed*9)*.065;else creature.rotation.z=0;});
    center.limbs.joyArms[1].rotation.z=(waveUntil.get('joy')??0)>elapsed?-.9+Math.sin(elapsed*10)*.25:0;
  }
  if(healingStart!==null){
    const progress=Math.min(1,(now-healingStart)/4200);healingLight.intensity=reducedMotion?6:8+Math.sin(elapsed*6)*4;
    center.healBalls.forEach((ball,i)=>{ball.position.y=.51+(reducedMotion?0:Math.sin(elapsed*3+i)*.045);});
    if(now-lastUiTime>120){lastUiTime=now;renderParty(progress);const bar=$('heal-progress');if(bar)bar.style.width=`${progress*100}%`;}
  }
  camera.updateMatrixWorld();
  const w=viewport.clientWidth,h=viewport.clientHeight;
  for(const spot of center.hotspots){const el=markerElements.get(spot.id);projection.copy(spot.point).project(camera);const visible=!center.shell.visible&&!dialog.open&&projection.z>-1&&projection.z<1&&Math.abs(projection.x)<.96&&Math.abs(projection.y)<.94;el.hidden=!visible;if(visible){el.style.left=`${(projection.x*.5+.5)*w}px`;el.style.top=`${(-projection.y*.5+.5)*h}px`;}}
  renderer.render(scene,camera);
}
renderer.setAnimationLoop(frame);$('loading').hidden=true;
renderer.domElement.addEventListener('webglcontextlost',e=>{e.preventDefault();renderer.setAnimationLoop(null);$('error').hidden=false;$('error-message').textContent='The graphics connection was interrupted. Reload to reopen the center.';});
// Optional WebMCP: advertise the same user-facing actions to compatible browsers.
if(document.modelContext?.registerTool){
  const lifecycle=new AbortController();
  window.addEventListener('pagehide',()=>lifecycle.abort(),{once:true});
  try{void Promise.resolve(document.modelContext.registerTool({name:'navigate_pokemon_center',description:'Select orbit or walking mode, or open the Nurse Joy or Pokemon PC interaction. Opening Nurse Joy does not start healing.',inputSchema:{type:'object',properties:{action:{type:'string',enum:['orbit','walk','nurse','pc']}},required:['action'],additionalProperties:false},annotations:{readOnlyHint:false,untrustedContentHint:false},execute:async(input)=>{if(!input||!['orbit','walk','nurse','pc'].includes(input.action)||Object.keys(input).some(k=>k!=='action'))throw new Error('Choose orbit, walk, nurse, or pc.');const {action}=input;if(action==='orbit'||action==='walk')setMode(action);else {if(state.healing)throw new Error('Healing is in progress.');const id=action==='nurse'?'joy':'pc',spot=center.hotspots.find(h=>h.id===id);if(mode==='walk'&&Math.hypot(center.trainer.position.x-spot.reach.x,center.trainer.position.z-spot.reach.z)>2.15)throw new Error('Walk closer to the station first.');activate(id);}return {mode,dialogOpen:dialog.open,party:state.getParty(),healing:state.healing};}},{signal:lifecycle.signal})).catch(()=>{});}catch{/* Optional API; the complete UI remains available. */}
}
