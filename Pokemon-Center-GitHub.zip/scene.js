import * as THREE from './vendor/three.module.js';
import { TextGeometry } from './vendor/addons/geometries/TextGeometry.js';

// One unit = roughly one meter. Everything is native, editable 3D geometry.
export function createCenter(font) {
  const world = new THREE.Group(); world.name = 'Pokemon Center — Viridian City';
  const shell = new THREE.Group(); shell.name = 'Removable roof and facade';
  const actors = new THREE.Group(); actors.name = 'Characters';
  const props = new THREE.Group(); props.name = 'Interior';
  world.add(shell, props, actors);
  const materials = new Map();
  const palette = { red:0xe85151, darkRed:0xb83b48, white:0xfff8eb, mint:0xb6d9c2, tile:0xe2efdf, blue:0x67babe, navy:0x35485e, pink:0xf6a0ae, black:0x273142, green:0x508c66, yellow:0xffd65a, wood:0xb57d52 };
  const unit = new THREE.BoxGeometry(1,1,1);
  const ball = new THREE.SphereGeometry(1,16,12);
  function mat(c, glow=0) { const key=`${c}/${glow}`; if(!materials.has(key)) materials.set(key,new THREE.MeshStandardMaterial({color:c,roughness:.78,emissive:c,emissiveIntensity:glow})); return materials.get(key); }
  function mesh(g,c,parent=world,glow=0) { const m=new THREE.Mesh(g,mat(c,glow)); m.castShadow=true; m.receiveShadow=true; parent.add(m); return m; }
  function box(x,y,z,w,h,d,c,parent=world) { const m=mesh(unit,c,parent); m.position.set(x,y,z); m.scale.set(w,h,d); return m; }
  function sphere(x,y,z,sx,sy,sz,c,parent=world) { const m=mesh(ball,c,parent); m.position.set(x,y,z); m.scale.set(sx,sy,sz); return m; }
  function cyl(x,y,z,rt,rb,h,c,parent=world,segments=20) { const m=mesh(new THREE.CylinderGeometry(rt,rb,h,segments),c,parent); m.position.set(x,y,z); return m; }
  function text(str,x,y,z,size,c,parent=world) { const g=new TextGeometry(str,{font,size,depth:.018,curveSegments:3,bevelEnabled:false}); g.computeBoundingBox(); g.translate(-g.boundingBox.max.x/2,0,0); const m=mesh(g,c,parent); m.position.set(x,y,z); return m; }
  function ring(x,y,z,r,c,parent=world,thickness=.055) { const m=mesh(new THREE.TorusGeometry(r,thickness,8,40),c,parent); m.position.set(x,y,z); return m; }
  function pokeball(x,y,z,r,parent=world) {
    const g=new THREE.Group(); g.position.set(x,y,z); parent.add(g);
    mesh(new THREE.SphereGeometry(r,20,12,0,Math.PI*2,0,Math.PI/2),palette.red,g);
    mesh(new THREE.SphereGeometry(r,20,12,0,Math.PI*2,Math.PI/2,Math.PI/2),palette.white,g);
    cyl(0,0,0,r+.003,r+.003,.06,palette.black,g);
    const rim=cyl(0,0,r,.12,.12,.07,palette.black,g); rim.rotation.x=Math.PI/2;
    const button=cyl(0,0,r+.04,.07,.07,.025,palette.white,g); button.rotation.x=Math.PI/2;
    return g;
  }
  function emblem(x,y,z,r,parent=world) {
    const g=new THREE.Group(); parent.add(g); g.position.set(x,y,z);
    const disk=cyl(0,0,0,r,r,.14,palette.white,g,48); disk.rotation.x=Math.PI/2;
    const edge=ring(0,0,.09,r*.78,palette.red,g,r*.16);
    box(0,0,.13,r*1.6,r*.18,.06,palette.red,g);
    const b=cyl(0,0,.2,r*.22,r*.22,.12,palette.white,g); b.rotation.x=Math.PI/2;
    return g;
  }
  // Floating miniature landscape, neatly edged like an architectural model.
  box(0,-.68,0,22,.95,18,0x5a7166);
  box(0,-.16,0,22,.16,18,0x89b987);
  box(0,-.02,1.6,14.2,.13,12.8,0xc9c4a7);
  box(0,.06,0,13.4,.17,10.4,palette.white);
  for(let x=-6;x<6;x++) for(let z=-5;z<5;z++) box(x+.5,.17,z+.5,.965,.12,.965,(x+z)%2===0?palette.tile:0xd3e6d7,props);
  for(let x=-2;x<=2;x++) for(let z=6;z<=8;z++) box(x,.015,z,.92,.08,.88,0xd7d0b5);
  // Walls. The camera looks toward the open front/right corner.
  box(0,2.45,-5,13.2,4.8,.28,palette.white);
  box(0,4.88,-5,13.5,.2,.45,palette.red);
  box(0,.68,-4.82,13,.68,.08,palette.blue);
  box(-6.5,1.85,0,.28,3.6,10.2,palette.white);
  box(-6.32,.68,0,.08,.68,10,palette.blue);
  box(-6.5,3.69,0,.42,.14,10.3,palette.red);
  box(6.5,.67,0,.28,1.23,10.2,palette.white);
  box(6.5,1.34,0,.4,.12,10.3,palette.red);
  for(const side of [-1,1]) { box(side*4.3,.65,5,4.4,1.2,.28,palette.white); box(side*4.3,1.3,5,4.5,.13,.4,palette.red); }
  box(0,.28,5.1,4,.16,.85,0xc5d9d8);
  box(0,.31,4.1,3.4,.06,1.1,palette.red,props);
  text('WELCOME',0,.355,4.5,.23,palette.white,props).rotation.x=-Math.PI/2;
  // Back wall signage and blue windows.
  box(0,3.45,-4.75,6.1,1.28,.16,palette.red,props);
  text('POKEMON CENTER',.45,3.33,-4.64,.34,palette.white,props);
  emblem(-2.48,3.52,-4.62,.34,props);
  for(const x of [-4.7,4.7]) {
    box(x,3.25,-4.78,2,1.7,.1,palette.blue,props);
    box(x,3.25,-4.69,1.7,1.43,.05,0xd9f2dc,props);
    box(x,3.25,-4.63,.07,1.5,.06,palette.white,props);
    box(x,3.25,-4.63,1.75,.07,.06,palette.white,props);
  }
  // Service desk, striped face, inset ball emblem, and healing machine.
  box(0,.97,-2.5,6.6,1.6,1.65,palette.red,props);
  box(0,1.83,-2.5,7,.16,1.9,palette.white,props);
  box(0,.8,-1.65,6.4,.15,.08,palette.darkRed,props);
  emblem(0,1.04,-1.59,.44,props);
  const healer=new THREE.Group(); healer.name='Healing machine'; props.add(healer); healer.position.set(1.8,1.94,-2.6);
  box(0,.14,0,1.95,.26,1.12,palette.navy,healer);
  box(0,.3,-.03,1.7,.09,.9,palette.pink,healer);
  box(0,.52,-.5,1.85,.8,.12,palette.navy,healer);
  box(0,.59,-.42,1.5,.45,.06,0x89e7d4,healer);
  const healBalls=[]; const pads=[];
  for(let i=0;i<6;i++){ const x=(i%3-1)*.49,z=Math.floor(i/3)*.43-.21; pads.push(cyl(x,.38,z,.2,.2,.05,palette.white,healer)); const p=pokeball(x,.51,z,.15,healer); p.visible=false; healBalls.push(p); }
  box(-2.3,1.98,-2.7,.95,.14,.6,palette.navy,props);
  const deskScreen=box(-2.3,2.29,-2.92,.86,.6,.1,palette.navy,props); deskScreen.rotation.x=-.18;
  box(-2.3,2.3,-2.85,.69,.42,.03,0x8ae0cf,props).rotation.x=-.18;
  // PC terminal.
  const pc=new THREE.Group(); pc.name='Pokemon PC'; props.add(pc); pc.position.set(5,.24,-2.7);
  box(0,.55,0,1.2,1.1,1.1,palette.blue,pc);
  box(0,1.59,-.2,1.46,1.35,.58,palette.navy,pc);
  box(0,1.68,.1,1.18,.88,.03,0x82ded2,pc);
  for(let i=0;i<3;i++) for(let j=0;j<2;j++) box((i-1)*.3,1.85-j*.31,.13,.2,.19,.02,palette.white,pc);
  box(0,1.12,.36,1.45,.17,.76,palette.white,pc);
  for(let i=-3;i<=3;i++) box(i*.14,1.22,.35,.1,.03,.26,palette.navy,pc);
  text('PC',0,2.4,-.05,.25,palette.navy,pc);
  // Waiting area, table, plant pots, and magazines.
  const bench=new THREE.Group(); props.add(bench); bench.name='Waiting area';
  for(const z of [.7,2.1]) {
    box(-4.8,.68,z,2.3,.25,.8,palette.red,bench);
    box(-4.8,1.06,z-.36,2.3,.8,.16,palette.red,bench);
    for(const x of [-5.65,-3.95]) box(x,.4,z,.12,.57,.55,palette.navy,bench);
    for(const x of [-5.58,-4.8,-4.02]) box(x,.835,z,.68,.07,.66,0xf47a70,bench);
  }
  cyl(-3.15,.75,2,.65,.65,.12,palette.white,props);
  cyl(-3.15,.44,2,.1,.1,.61,palette.navy,props);
  box(-3.2,.835,2,.6,.04,.39,palette.blue,props).rotation.y=.3;
  box(-3.01,.88,2.11,.45,.04,.32,palette.yellow,props).rotation.y=-.3;
  function plant(x,z,scale=1,parent=world){ const g=new THREE.Group(); g.position.set(x,.18,z); g.scale.setScalar(scale); parent.add(g); cyl(0,.27,0,.31,.25,.52,palette.white,g); cyl(0,.56,0,.28,.28,.05,0x755841,g); for(let i=0;i<7;i++){ const a=i*2.4; const leaf=sphere(Math.cos(a)*.21,.92+Math.sin(i)*.17,Math.sin(a)*.21,.14,.4,.13,i%2?0x438a68:0x73aa77,g); leaf.rotation.z=Math.cos(a)*.5; leaf.rotation.x=Math.sin(a)*.5; } return g; }
  plant(-5.7,-3.7,1.05,props); plant(5.75,3.9,1.15,props);
  // Exterior mode restores the upper shell and gabled red roof.
  box(6.5,3.1,0,.28,3.4,10.2,palette.white,shell);
  box(-6.5,4.3,0,.28,1.1,10.2,palette.white,shell);
  for(const side of [-1,1]) {
    box(side*4.3,3,5,4.4,3.35,.28,palette.white,shell);
    box(side*4.3,2.8,5.17,2.9,1.5,.12,palette.blue,shell);
    box(side*4.3,2.8,5.25,2.58,1.22,.05,0xafdddf,shell);
    box(side*4.3,2.8,5.3,.1,1.26,.08,palette.white,shell);
  }
  box(0,4.3,5,4.4,1.15,.4,palette.red,shell);
  text('POKEMON',0,4.14,5.24,.39,palette.white,shell);
  for(const side of [-1,1]) box(side*2.06,2.2,5.06,.16,3.8,.25,palette.blue,shell);
  const doors=new THREE.Group(); shell.add(doors);
  for(const side of [-1,1]){
    const door=new THREE.Group(); door.position.set(side*.94,1.97,5.02); doors.add(door);
    box(0,0,0,1.78,3.3,.12,palette.blue,door);
    box(0,.25,.08,1.49,2.52,.035,0xaedbdc,door);
    box(side*.52,-.1,.13,.07,.45,.08,palette.white,door);
  }
  for(const side of [-1,1]) {
    const panel=box(side*3.42,5.68,0,7.22,.32,10.9,palette.red,shell); panel.rotation.z=-side*.245;
    for(let z=-5.1;z<=5.2;z+=.53){ const seam=box(side*3.42,5.88,z,7.22,.045,.055,0xcf494e,shell); seam.rotation.z=-side*.245; }
  }
  box(0,6.57,0,.32,.26,11,palette.darkRed,shell);
  const gableShape=new THREE.Shape(); gableShape.moveTo(-6.5,0); gableShape.lineTo(0,1.62); gableShape.lineTo(6.5,0); gableShape.closePath();
  const gable=mesh(new THREE.ExtrudeGeometry(gableShape,{depth:.15,bevelEnabled:false}),palette.red,shell); gable.position.set(0,4.83,5);
  emblem(0,5.62,5.32,.67,shell);
  // A recognizably Pokemon Center roadside sign.
  cyl(8,.95,4,.1,.1,1.85,palette.navy);
  box(8,2.5,4,1.7,1.7,.3,palette.red);
  emblem(8,2.65,4.2,.51); text('CENTER',8,1.91,4.18,.18,palette.white);
  // Stylized grove and little flowers give the diorama a sense of place.
  function tree(x,z,h=1){const g=new THREE.Group();g.position.set(x,0,z);g.scale.setScalar(h);world.add(g);cyl(0,1,0,.18,.24,2,0x936742,g,9);sphere(0,2.65,0,1.18,1.45,1.15,0x548b60,g);sphere(-.45,2.15,.2,.83,.93,.83,0x68a070,g);sphere(.47,2.5,.15,.75,1,.79,0x74ae7b,g);return g;}
  tree(-8.65,-5.7,1.2); tree(-8.9,-1.2,.85); tree(8.6,-6,1.18); tree(9.1,-2.4,.78);
  for(const side of [-1,1]) for(let i=0;i<5;i++){ const x=side*(3.5+i*1.2),z=7.4+Math.sin(i*3)*.5; sphere(x,.16,z,.13,.12,.13,i%2?0xffda6a:0xffa9b4); cyl(x,.05,z,.025,.025,.18,0x5a8e5b); }
  for(const x of [-7.5,7.5]) { cyl(x,1.1,6,.08,.1,2.2,palette.navy); box(x,2.3,6,.45,.52,.45,palette.white); box(x,2.6,6,.6,.1,.6,palette.navy); }
  // Characters built from small, separate meshes, ready to animate or export.
  function person(x,z,nurse=false){
    const g=new THREE.Group(); actors.add(g); g.position.set(x,.23,z); g.name=nurse?'Nurse Joy':'Trainer';
    const skin=0xffd4ad,cloth=nurse?palette.pink:palette.blue;
    const legs=[]; for(const side of [-1,1]){ const leg=box(side*.15,.25,0,.22,.49,.24,nurse?palette.white:palette.navy,g); legs.push(leg); sphere(side*.15,.09,.1,.16,.1,.22,nurse?palette.red:palette.black,g); }
    sphere(0,.79,0,.37,.49,.25,cloth,g);
    if(nurse)box(0,.76,.23,.43,.61,.06,palette.white,g);
    sphere(0,1.37,0,.34,.34,.31,skin,g);
    for(const s of [-1,1]){ sphere(s*.13,1.4,.289,.036,.05,.025,palette.black,g); sphere(s*.21,1.29,.259,.059,.03,.018,0xf1a298,g); }
    sphere(0,1.56,-.07,.36,.21,.29,nurse?0xe886a0:0x665045,g);
    if(nurse){for(const s of [-1,1])sphere(s*.4,1.35,-.09,.2,.22,.22,0xe886a0,g);box(0,1.7,.05,.52,.17,.33,palette.white,g);box(0,1.72,.226,.13,.045,.015,palette.red,g);box(0,1.72,.229,.045,.13,.015,palette.red,g);}
    else { sphere(0,1.64,-.02,.38,.14,.33,palette.red,g); box(0,1.6,.28,.55,.06,.37,palette.red,g); box(0,.85,-.26,.5,.62,.19,palette.yellow,g); }
    const arms=[]; for(const s of [-1,1]){const arm=new THREE.Group();arm.position.set(s*.4,1,0);g.add(arm);sphere(0,-.17,0,.13,.28,.14,cloth,arm);sphere(0,-.4,.01,.105,.12,.11,skin,arm);arms.push(arm);}
    g.userData.legs=legs;g.userData.arms=arms;return g;
  }
  const joy=person(-.9,-3.77,true); const trainer=person(.1,5.8,false);
  function pokemon(kind,x,z){
    const g=new THREE.Group();g.position.set(x,.23,z);g.name=kind;actors.add(g);
    if(kind==='Pikachu'){
      sphere(0,.5,0,.35,.46,.28,palette.yellow,g);sphere(0,1,0,.39,.34,.32,palette.yellow,g);
      for(const s of [-1,1]){ const ear=sphere(s*.22,1.45,-.01,.085,.37,.09,palette.yellow,g);ear.rotation.z=-s*.22;const tip=sphere(s*.28,1.71,-.01,.067,.15,.074,palette.black,g);tip.rotation.z=-s*.22;sphere(s*.15,1.06,.296,.045,.061,.025,palette.black,g);sphere(s*.28,.92,.249,.08,.066,.026,palette.red,g);sphere(s*.19,.15,.12,.17,.11,.23,palette.yellow,g);sphere(s*.33,.64,.11,.12,.22,.11,palette.yellow,g);}
      sphere(0,.94,.323,.03,.025,.018,palette.black,g);
      const tail=box(.38,.59,-.3,.18,.59,.1,palette.yellow,g);tail.rotation.z=-.75;const t2=box(.64,.88,-.3,.22,.52,.1,palette.yellow,g);t2.rotation.z=.4;
    } else if(kind==='Bulbasaur'){
      sphere(0,.4,0,.49,.35,.62,0x71b99d,g);sphere(0,.65,.4,.47,.4,.4,0x7acbb0,g);
      for(const s of [-1,1]){sphere(s*.31,.18,.34,.18,.21,.22,0x71b99d,g);sphere(s*.3,.18,-.38,.18,.2,.22,0x71b99d,g);const ear=mesh(new THREE.ConeGeometry(.16,.31,4),0x7acbb0,g);ear.position.set(s*.32,1,.4);sphere(s*.22,.69,.75,.065,.08,.024,0xc84e67,g);box(s*.26,.43,.76,.1,.13,.016,0x358f77,g);}
      sphere(0,.82,-.22,.43,.45,.42,0x518c60,g);for(let i=0;i<5;i++){const l=mesh(new THREE.ConeGeometry(.2,.57,5),0x6ba24f,g);l.position.set(Math.cos(i*1.25)*.18,1.09,Math.sin(i*1.25)*.18-.22);l.rotation.z=Math.cos(i*1.25)*.4;}
    } else if(kind==='Charmander'){
      sphere(0,.55,0,.31,.45,.28,0xf2a05a,g);sphere(0,1.02,.04,.34,.34,.32,0xf2a05a,g);sphere(0,.52,.235,.22,.31,.08,0xffdc9d,g);
      for(const s of [-1,1]){sphere(s*.14,1.08,.33,.048,.072,.024,0x30464a,g);sphere(s*.21,.17,.09,.18,.12,.24,0xf2a05a,g);sphere(s*.32,.66,.06,.1,.23,.11,0xf2a05a,g);}
      const tail=sphere(.3,.31,-.4,.15,.16,.45,0xf2a05a,g);tail.rotation.y=-.65;sphere(.61,.57,-.67,.15,.31,.14,palette.red,g);sphere(.61,.56,-.65,.1,.21,.1,palette.yellow,g);
    } else {
      sphere(0,.5,0,.37,.4,.3,0x77c5d3,g);sphere(0,1.01,.05,.34,.33,.32,0x85d7df,g);sphere(0,.52,-.12,.4,.42,.28,0xaf825a,g);sphere(0,.52,.2,.29,.35,.1,0xffdf9a,g);
      for(const s of [-1,1]){sphere(s*.14,1.08,.34,.045,.07,.026,0x513a58,g);sphere(s*.25,.18,.07,.17,.13,.22,0x77c5d3,g);sphere(s*.36,.68,.05,.12,.24,.13,0x77c5d3,g);}ring(.35,.35,-.34,.18,0x77c5d3,g,.08);
    }return g;
  }
  const pikachu=pokemon('Pikachu',2.2,2.45); pikachu.rotation.y=-.4;
  const bulbasaur=pokemon('Bulbasaur',-4.6,3.5);bulbasaur.rotation.y=.65;
  const charmander=pokemon('Charmander',4.35,.7);charmander.rotation.y=-.4;
  const squirtle=pokemon('Squirtle',-7.7,4.5);squirtle.rotation.y=.4;
  // Interactive hotspots have semantic IDs rather than object-name guessing.
  const hotspots=[
    {id:'joy',label:'Talk to Nurse Joy',group:joy,point:new THREE.Vector3(-.9,2.45,-2.1),reach:new THREE.Vector3(-.9,0,-.6)},
    {id:'heal',label:'Heal your party',group:healer,point:new THREE.Vector3(1.8,3,-2.6),reach:new THREE.Vector3(1.8,0,-.7)},
    {id:'pc',label:'Open Pokémon PC',group:pc,point:new THREE.Vector3(5,3,-2.7),reach:new THREE.Vector3(5,0,-1.1)},
    {id:'pikachu',label:'Say hello to Pikachu',group:pikachu,point:new THREE.Vector3(2.2,2.2,2.45),reach:new THREE.Vector3(2.2,0,2.45)},
    {id:'bulbasaur',label:'Say hello to Bulbasaur',group:bulbasaur,point:new THREE.Vector3(-4.6,1.8,3.5),reach:new THREE.Vector3(-4.6,0,3.5)},
    {id:'charmander',label:'Say hello to Charmander',group:charmander,point:new THREE.Vector3(4.35,2,.7),reach:new THREE.Vector3(4.35,0,.7)},
    {id:'squirtle',label:'Say hello to Squirtle',group:squirtle,point:new THREE.Vector3(-7.7,2,4.5),reach:new THREE.Vector3(-7.7,0,4.5)}
  ];
  for(const h of hotspots)h.group.traverse(o=>{if(o.isMesh)o.userData.interaction=h.id;});
  const obstacles=[[-3.65,3.65,-3.45,-1.38],[4.15,5.85,-3.5,-1.75],[-6,-3.6,.2,2.55],[-3.85,-2.45,1.3,2.7],[-6.15,-5.2,-4.2,-3.2],[5.25,6.15,3.3,4.5]];
  function canStand(x,z){
    if(x < -10.25 || x > 10.25 || z < -8.1 || z > 8.25)return false;
    const r=.27;
    // Thick wall rectangles prevent corner clipping, including the open facade.
    const walls=[[-6.8,-6.22,-5.3,5.15],[6.22,6.8,-5.3,5.15],[-6.8,6.8,-5.3,-4.64],[-6.7,-2.0,4.8,5.25],[2,6.7,4.8,5.25]];
    return ![...obstacles,...walls].some(([a,b,c,d])=>x+r>a&&x-r<b&&z+r>c&&z-r<d);
  }
  const lightPositions=[[-7.5,2.3,6],[7.5,2.3,6],[0,3,-1.5]];
  shell.visible=false;
  // Keep export metadata serializable; animation handles are returned separately.
  const limbs={legs:trainer.userData.legs,arms:trainer.userData.arms,joyArms:joy.userData.arms};
  trainer.userData={};joy.userData={};
  return {world,shell,actors,trainer,joy,healer,healBalls,pads,hotspots,canStand,limbs,creatures:[pikachu,bulbasaur,charmander,squirtle],lightPositions};
}
