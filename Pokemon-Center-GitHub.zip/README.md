# Pokémon Center — interactive 3D diorama

A small, explorable Pokémon Center inspired by Viridian City, built with Three.js. All geometry and interactions are editable JavaScript. Every runtime asset is included; there are no API keys, external services, remote fonts, or build steps.

## Put it on GitHub Pages

1. Create a GitHub repository and upload the **contents** of this folder. `index.html`, `app.js`, `scene.js`, `styles.css`, `state.js`, `assets/`, and `vendor/` must be at the repository root. Keep their folder structure intact.
2. In the repository, open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, select **main** and **/(root)**, and save.
4. Open the published link shown on that page after deployment completes.

All asset paths are relative, so this works under a repository subpath such as `username.github.io/pokemon-center/`.

Official instructions: [Configure a GitHub Pages publishing source](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site).

## Open it locally

The separately supplied **Pokemon-Center.html** is self-contained. Open that file directly in a current browser; it needs no server or internet connection.

To work on the modular source in this folder, run:

```sh
python3 -m http.server 8000
```

Then open `http://localhost:8000`. A static-file server is needed for the modular source because browsers restrict module imports and asset requests from `file://` URLs. Requires a browser with WebGL 2.

## Things to do

- **Orbit:** drag to rotate, scroll or pinch to zoom, right-drag or two-finger drag to pan.
- **Explore:** walk with WASD, arrow keys, or the onscreen directional pad. Movement follows the camera's screen directions; furniture and walls block your path. Enter through the front doorway.
- **Interact:** click a character or a + marker. In Explore mode, walk close and press E or use the Interact button.
- **Nurse Joy:** heal the three Pokémon in your party. HP increases during the healing sequence; close the dialog to watch the station animate.
- **Pokémon PC:** select a party member and exchange it with the Pokémon in Box 01. Each Pokémon keeps its own HP.
- **Pokémon:** meet Pikachu, Bulbasaur, Charmander, and Squirtle.
- **Show roof / Cutaway:** switch between the complete building and the open interior.
- **Daylight / Evening:** switch lighting. Sound is off by default; turn it on for short interaction sounds.
- **Reset view:** return to the original camera and entrance. Party changes remain until the page reloads.
- **Download 3D model:** export the complete building, grounds, and characters as GLB. A ready-made version is also in `models/pokemon-center.glb`.

This is a small exploration experience. There are no battles or account system. Party state lasts for the current visit and resets on reload. Keyboard-accessible station buttons provide an alternative to targeting the 3D objects. Reduced-motion preferences disable character bounces, walking animation, and camera transitions.

## Files and customization

| File | Purpose |
| --- | --- |
| `index.html` | Interface and startup error handling |
| `app.js` | Camera, walking, dialogue, healing, audio, lighting, and export |
| `scene.js` | Procedural building, landscape, furniture, and character geometry |
| `state.js` | Party, individual HP, and PC exchange rules |
| `styles.css` | Desktop and phone layouts |
| `models/pokemon-center.glb` | Complete static model, editable in Blender and glTF-compatible tools |
| `vendor/` | Locally included Three.js 0.180.0 and necessary addons |
| `assets/` | Included typeface data for the 3D signs |

Edit the palette and dimensions in `scene.js` to change the building. Edit `catalog` in `state.js` to change the starting party. The GLB stores geometry and materials; the game interactions remain in the website's JavaScript. Its removable roof is a named group. The standalone HTML is a bundled snapshot of these sources.

## Validation

Checked JavaScript syntax, local module/asset references, complete scene construction, geometric camera fit on desktop and phone aspect ratios, healing state transitions, exchange restrictions and HP retention, wall/furniture collisions, all station approach points, and the GLB structure. Live browser rendering and touch interaction were not tested in this environment.

## Credits

Fan-made procedural interpretation; Pokémon and its character names belong to their respective owners. This project is not affiliated with Nintendo, Game Freak, or The Pokémon Company.

Three.js 0.180.0 is included under its MIT license; see `vendor/THREE-LICENSE.txt`. The bundled Helvetiker typeface includes its original license metadata in `assets/helvetiker_bold.typeface.json`. Three.js sources: [threejs.org](https://threejs.org/) and [release 0.180.0](https://github.com/mrdoob/three.js/tree/r180). No third-party game models, sprites, or music are used.
