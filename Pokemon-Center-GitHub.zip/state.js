export const catalog = [
  {id:'pikachu',name:'Pikachu',number:'025',level:12,type:'Electric',hp:22,max:42,color:'#a98016',tint:'#fbefbd',initial:'P'},
  {id:'bulbasaur',name:'Bulbasaur',number:'001',level:10,type:'Grass / Poison',hp:16,max:39,color:'#477d55',tint:'#d8ead5',initial:'B'},
  {id:'charmander',name:'Charmander',number:'004',level:11,type:'Fire',hp:14,max:38,color:'#b86c37',tint:'#f8e0c7',initial:'C'},
  {id:'squirtle',name:'Squirtle',number:'007',level:10,type:'Water',hp:34,max:40,color:'#477e9a',tint:'#d8eaf0',initial:'S'}
];
export function createGameState(){
  const pokemon=catalog.map(p=>({...p}));
  const party=['pikachu','bulbasaur','charmander'];
  let healing=false;
  return {
    pokemon,party,
    get healing(){return healing;},
    getParty:()=>party.map(id=>pokemon.find(p=>p.id===id)),
    getStored:()=>pokemon.filter(p=>!party.includes(p.id)),
    beginHealing(){if(healing)return false;healing=true;return true;},
    finishHealing(){if(!healing)return false;for(const p of this.getParty())p.hp=p.max;healing=false;return true;},
    swap(partyId,storedId){if(healing)return false;const i=party.indexOf(partyId);if(i<0||party.includes(storedId)||!pokemon.some(p=>p.id===storedId))return false;party[i]=storedId;return true;}
  };
}
